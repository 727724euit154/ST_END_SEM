
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.lang.Thread.*;

public class CartPage {

    private WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickCartButton() {
        driver.findElement(By.className("shopping_cart_link")).click();
    }

    public void clickCheckOut() {
        driver.findElement(By.id("checkout")).click();
    }

    public void fillInfo(String firstName, String lastName, String zip) {
        driver.findElement(By.id("first-name")).sendKeys(firstName);
        driver.findElement(By.id("last-name")).sendKeys(lastName);
        driver.findElement(By.id("postal-code")).sendKeys(zip);
        driver.findElement(By.id("continue")).click();
    }

    public void overviewPage() throws InterruptedException {
        Thread.sleep(3000);
        driver.findElement(By.id("finish")).click();
    }
}

