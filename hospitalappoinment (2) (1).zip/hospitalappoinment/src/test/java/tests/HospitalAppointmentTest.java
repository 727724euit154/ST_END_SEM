package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.AppointmentPage;
import pages.DepartmentPage;
import pages.DoctorPage;
import pages.PatientPage;

public class HospitalAppointmentTest {

    WebDriver driver;

    DepartmentPage departmentPage;
    DoctorPage doctorPage;
    AppointmentPage appointmentPage;
    PatientPage patientPage;

    @BeforeMethod
    public void setup() {

        driver = new ChromeDriver();

        driver.get(
                "https://mouneshgouda.github.io/Hospital-Appointment/"
        );

        driver.manage().window().maximize();

        departmentPage = new DepartmentPage(driver);
        doctorPage = new DoctorPage(driver);
        appointmentPage = new AppointmentPage(driver);
        patientPage = new PatientPage(driver);
    }

    @Test
    public void bookHospitalAppointment() {

        departmentPage.selectCardiology();

        doctorPage.selectDoctor();

        doctorPage.clickNext();

        appointmentPage.selectDate();

        appointmentPage.selectTime();

        appointmentPage.clickNext();

        patientPage.enterPatientDetails();

        patientPage.clickNext();

        patientPage.confirmAppointment();

        String appointmentId = patientPage.getBookingId();

        System.out.println(
                "Appointment booked successfully!"
        );

        System.out.println(
                "Appointment ID: " + appointmentId
        );

        Assert.assertTrue(
                appointmentId != null && !appointmentId.isEmpty(),
                "Appointment ID was not generated"
        );
    }

    @AfterMethod
    public void tearDown() throws InterruptedException {

        Thread.sleep(3000);

    }
}
