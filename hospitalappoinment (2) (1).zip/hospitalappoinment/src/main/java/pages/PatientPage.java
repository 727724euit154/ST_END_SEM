package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PatientPage {

    WebDriver driver;

    public PatientPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterPatientDetails() {

        driver.findElement(
                By.id("patientName")
        ).sendKeys("Karthick Geethanath");

        driver.findElement(
                By.id("phone")
        ).sendKeys("6379193148");

        driver.findElement(
                By.id("email")
        ).sendKeys("karthick@gmail.com");

        driver.findElement(
                By.id("dob")
        ).sendKeys("11/11/2006");

        driver.findElement(
                By.id("gender")
        ).sendKeys("Male");

        driver.findElement(
                By.id("patientType")
        ).sendKeys("New patient");

        driver.findElement(
                By.id("reason")
        ).sendKeys("Regular consultation");
    }

    public void clickNext() {
        driver.findElement(
                By.id("patientNext")
        ).click();
    }

    public void confirmAppointment() {
        driver.findElement(
                By.id("confirmButton")
        ).click();
    }

    public String getBookingId() {
        return driver.findElement(
                By.id("bookingId")
        ).getText();
    }
}
