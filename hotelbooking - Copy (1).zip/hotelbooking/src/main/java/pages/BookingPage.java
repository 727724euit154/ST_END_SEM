package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;

public class BookingPage {

    WebDriver driver;


    public BookingPage(WebDriver driver) {
        this.driver = driver;
    }


    public void enterDetails() throws InterruptedException {


        driver.findElement(By.id("name"))
                .sendKeys("Karthick Geethanath");


        driver.findElement(By.id("email"))
                .sendKeys("karthick@gmail.com");


        JavascriptExecutor js =
                (JavascriptExecutor) driver;



        WebElement checkIn =
                driver.findElement(By.id("bookingCheckIn"));


        js.executeScript(
                "arguments[0].value='2026-09-19';",
                checkIn
        );



        WebElement checkOut =
                driver.findElement(By.id("bookingCheckOut"));


        js.executeScript(
                "arguments[0].value='2026-09-20';",
                checkOut
        );



        driver.findElement(By.id("bookingGuests"))
                .clear();


        driver.findElement(By.id("bookingGuests"))
                .sendKeys("2");


        Thread.sleep(2000);
    }



    public void confirmBooking() throws InterruptedException {


        WebElement button =
                driver.findElement(
                        By.xpath("//button[contains(text(),'Confirm Reservation')]")
                );


        JavascriptExecutor js =
                (JavascriptExecutor) driver;


        js.executeScript(
                "arguments[0].scrollIntoView(true);",
                button
        );


        Thread.sleep(1000);


        button.click();
    }
}

