package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RoomsPage{
    WebDriver driver;
    public RoomsPage(WebDriver driver){
        this.driver=driver;
    }
    public void bookRoom() throws InterruptedException {
        WebElement button = driver.findElement(By.xpath("(//button[contains(text(),'Book Reservation')])[1]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", button);
        Thread.sleep(2000);
        button.click();
    }
}