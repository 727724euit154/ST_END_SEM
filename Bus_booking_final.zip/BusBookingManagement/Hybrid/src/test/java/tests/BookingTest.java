package tests;
import org.testng.annotations.BeforeMethod;
import utils.ConfigReader;
import base.BaseTest;
import pages.*;
import org.testng.annotations.Test;
public class BookingTest extends BaseTest{
    @BeforeMethod
    public void start() throws Exception{
        setup();
    }
    @Test
    public void bookingTest(){
        HomePage homePage = new HomePage(driver);
        homePage.searchBus(
                ConfigReader.get("from"),
                ConfigReader.get("to"),
                ConfigReader.get("date")
        );
        Buspage buspage = new Buspage(driver);
        buspage.selectBus(
                ConfigReader.get("bus")
        );
        PassengerPage passengerPage = new PassengerPage(driver);
        passengerPage.enterDetails(
                ConfigReader.get("name"),
                ConfigReader.get("age"),
                ConfigReader.get("phone"),
                ConfigReader.get("seat")
        );
        passengerPage.booking();
    }
}