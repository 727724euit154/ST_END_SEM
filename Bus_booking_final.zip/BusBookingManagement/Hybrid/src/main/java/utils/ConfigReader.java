package utils;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
public class ConfigReader {
    public static Properties p=new Properties();
    static{
        try {
            p.load(new FileInputStream("src/test/resources/config.properties"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String get(String key){
        return p.getProperty(key);
    }
}