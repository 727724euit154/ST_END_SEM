package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
public class PassengerPage {
    WebDriver driver;
    public PassengerPage(WebDriver driver) {
        this.driver = driver;
    }
    public void enterDetails(String name,String age,String phone,String seat){
        driver.findElement(By.id("name")).sendKeys(name);
        driver.findElement(By.id("age")).sendKeys(age);
        driver.findElement(By.id("phone")).sendKeys(phone);
        driver.findElement(By.id("seat")).sendKeys(seat);
    }
    public void booking(){
        driver.findElement(By.xpath("//button[contains(text(),'Book')]")).click();
    }
}
