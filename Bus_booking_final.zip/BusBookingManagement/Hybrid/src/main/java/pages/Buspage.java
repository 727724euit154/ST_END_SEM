package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
public class Buspage {
    WebDriver driver;
    public Buspage(WebDriver driver) {
        this.driver = driver;
    }
    public void selectBus(String bus) {
        driver.findElement(By.xpath("//tr[td='"+bus+"']//button")).click();
    }
}
