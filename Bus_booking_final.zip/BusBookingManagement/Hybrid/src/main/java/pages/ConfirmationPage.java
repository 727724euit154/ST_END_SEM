package pages;
import org.openqa.selenium.WebDriver;
public class ConfirmationPage {
    WebDriver driver;
    public ConfirmationPage(WebDriver driver){
        this.driver = driver;
    }
    public void verify(){
        System.out.print("Booking Done");
    }
}
