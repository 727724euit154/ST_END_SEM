package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

public class HomePage{
    WebDriver driver;
    public HomePage(WebDriver driver){
        this.driver = driver;
    }
    public void searchBus(String from,String to,String date){
        Select selectFrom = new Select(driver.findElement(By.id("from")));
        selectFrom.selectByVisibleText(from);
        Select selectTo = new Select(driver.findElement(By.id("to")));
        selectTo.selectByVisibleText(to);
        driver.findElement(By.id("date")).sendKeys(date);
        driver.findElement(By.xpath("//button[contains(text(),'Search Bus')]")).click();

    }
}