package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class InsurancePage {

    WebDriver driver;

    public InsurancePage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectCar() throws InterruptedException {

        driver.findElement(
                By.cssSelector(".insurance[data-type='Car']")
        ).click();

        Thread.sleep(500);
    }

    public void clickNext() throws InterruptedException {

        driver.findElement(By.id("nextBtn")).click();

        Thread.sleep(1000);
    }
}