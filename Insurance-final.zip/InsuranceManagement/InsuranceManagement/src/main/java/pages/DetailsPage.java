package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DetailsPage {

    WebDriver driver;

    public DetailsPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterDetails() throws InterruptedException {

        driver.findElement(By.id("firstName")).sendKeys("Hariharan");
        driver.findElement(By.id("lastName")).sendKeys("M");
        driver.findElement(By.id("email")).sendKeys("hariharan@gmail.com");
        driver.findElement(By.id("age")).sendKeys("20");

        Thread.sleep(500);
    }

    public void clickNext() throws InterruptedException {

        driver.findElement(By.id("nextBtn")).click();

        Thread.sleep(1000);
    }
}
