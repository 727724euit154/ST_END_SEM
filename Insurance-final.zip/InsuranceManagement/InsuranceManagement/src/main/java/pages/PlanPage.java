
package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PlanPage {

    WebDriver driver;

    public PlanPage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectStandard() throws InterruptedException {

        driver.findElement(
                By.cssSelector(".plan[data-plan='Standard']")
        ).click();

        Thread.sleep(500);
    }

    public void clickNext() throws InterruptedException {

        driver.findElement(By.id("nextBtn")).click();

        Thread.sleep(1000);
    }
}
