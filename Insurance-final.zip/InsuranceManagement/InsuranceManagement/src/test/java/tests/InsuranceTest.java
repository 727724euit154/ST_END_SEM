package tests;

import base.BaseTest;
import pages.ConfirmationPage;
import pages.DetailsPage;
import pages.HomePage;
import pages.InsurancePage;
import pages.PlanPage;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class InsuranceTest extends BaseTest {


    @BeforeMethod
    public void beforeTest() {
        setup();
    }


    @Test
    public void getCarInsuranceQuote() throws InterruptedException {


        HomePage homePage = new HomePage(driver);
        InsurancePage insurancePage = new InsurancePage(driver);
        PlanPage planPage = new PlanPage(driver);
        DetailsPage detailsPage = new DetailsPage(driver);
        ConfirmationPage confirmationPage =
                new ConfirmationPage(driver);

        homePage.clickGetQuote();
        homePage.scrollDown();

        insurancePage.selectCar();
        insurancePage.clickNext();
        planPage.selectStandard();
        planPage.clickNext();
        detailsPage.enterDetails();
        detailsPage.clickNext();
        confirmationPage.clickConfirm();
        String message =
                confirmationPage.getSuccessMessage();

        System.out.println("Message: " + message);


    }

    // After Test
    @AfterMethod
    public void afterTest() {
        teardown();
        System.out.println("Browser closed");
    }

    private void teardown() {
    }
}