package org.example;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Game {
    private static final Logger log= LogManager.getLogger(Game.class);

    @Test
    public void startGame() throws  InterruptedException{
        log.info("Open Webpage");
        WebDriver driver=new ChromeDriver();
        driver.get("https://play2048.co/");
        log.debug("Starting Game");
        for(int i=0;i<200;i++){
            log.trace("Moving Down");

            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_DOWN);
            Thread.sleep(10);

            log.trace("Moving right");

            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_RIGHT);
            Thread.sleep(10);

            log.trace("Moving left");

            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_LEFT);
            Thread.sleep(10);

            log.trace("Moving Up");

            driver.findElement(By.tagName("body")).sendKeys(Keys.ARROW_UP);
            Thread.sleep(10);

        }

        log.warn("No Waring ");
        log.error("No small Error");
        log.fatal("The Automation in fine");
    }
}
