package org.example;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

public class Exp2 {
    public static void main(String args[]){
        WebDriver driver=new ChromeDriver();
        driver.get("https://demoqa.com/automation-practice-form");
        WebElement firstName=driver.findElement(By.id("firstName"));
        firstName.sendKeys("MANIKANDA ");
        WebElement secondName=driver.findElement(By.id("lastName"));
        secondName.sendKeys(" PRABHU");
        WebElement email=driver.findElement(By.id("userEmail"));
        email.sendKeys("prabhumanikanda607@gmail.com");
        WebElement male=driver.findElement(By.id("gender-radio-1"));
        male.click();
        WebElement number=driver.findElement(By.id("userNumber"));
        number.sendKeys("6382648908");
        WebElement dob=driver.findElement(By.id("dateOfBirthInput"));
        dob.click();
        dob.sendKeys(Keys.CONTROL+"a");
        dob.sendKeys("4 May 2007");
        dob.sendKeys(Keys.ENTER);
        WebElement sub=driver.findElement(By.id("subjectsInput"));
        sub.sendKeys("Computer");
        sub.sendKeys(Keys.ENTER);
        WebElement hob=driver.findElement(By.id("hobbies-checkbox-1"));
        hob.click();

        WebElement pic=driver.findElement(By.id("uploadPicture"));
        pic.sendKeys("C:/Users/navee/OneDrive/Pictures/black_panther_is_sitting_in_car_background_4k_hd_black_panther-3840x2160.jpg");


        WebElement address=driver.findElement(By.id("currentAddress"));
        address.sendKeys("2/165 A Nethaji Nagar Krishnagiri Tamilnadu");

        WebElement state= driver.findElement(By.id("react-select-3-input"));
        state.sendKeys("NCR");
        state.sendKeys(Keys.ENTER);

        WebElement city=driver.findElement(By.id("react-select-4-input"));
        city.sendKeys("Delhi");

        city.sendKeys(Keys.ENTER);

        WebElement submit=driver.findElement(By.id("submit"));
        submit.sendKeys(Keys.ENTER);
    }
}