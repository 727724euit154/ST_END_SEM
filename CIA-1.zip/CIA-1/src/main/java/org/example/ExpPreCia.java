package org.example;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class ExpPreCia {

    public static void main(String[] args) throws Exception {
        new File("reports").mkdir();
        ExtentReports extent = new ExtentReports();
        ExtentSparkReporter spark = new ExtentSparkReporter("reports/report.html");
        extent.attachReporter(spark);

        ExtentTest test = extent.createTest("OrangeHRM Automation Test");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/");
        Thread.sleep(3000);
        test.pass("Website Opened Successfully");
        capture(driver, test, "01_Home");
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(3000);
        test.pass("Login Validation Successful");
        capture(driver, test, "02_Dashboard");
        driver.findElement(By.xpath("//span[text()='PIM']")).click();
        Thread.sleep(2000);
        test.pass("PIM View Engine Loaded");
        capture(driver, test, "03_PIM");
        driver.findElement(By.xpath("//span[text()='Admin']")).click();
        Thread.sleep(2000);
        test.pass("Admin Management Frame Loaded");
        capture(driver, test, "04_Admin");
        extent.flush();
        System.out.println("Automation Completed Successfully!");
        System.out.println("Report Path: reports/report.html");
    }
    public static void capture(WebDriver driver, ExtentTest test, String name) throws Exception {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        File dest = new File("reports/" + name + ".png");
        Files.copy(src.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        test.addScreenCaptureFromPath(name + ".png");
    }
}