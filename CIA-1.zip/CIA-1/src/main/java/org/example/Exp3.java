import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exp3 {
    public static void main(String[] args){
        ChromeDriver driver=new ChromeDriver();
        driver.get("https://demoqa.com/automation-practice-form");

        driver.findElement(By.id("firstName")).sendKeys("mani");
        driver.findElement(By.id("lastName")).sendKeys("prabhu");
        driver.findElement(By.id("userEmail")).sendKeys("prabhu8767@gmail.com");
        driver.findElement(By.id("gender-radio-3")).click();
        driver.findElement(By.id("userNumber")).sendKeys("9363141455");
        WebElement dob=driver.findElement(By.id("dateOfBirthInput"));
        dob.sendKeys(Keys.CONTROL+"a");
        dob.sendKeys("17 11 2006");
        dob.sendKeys(Keys.ENTER);

        WebElement sub=driver.findElement(By.id("subjectsInput"));
        sub.sendKeys("English");
        sub.sendKeys(Keys.ENTER);
        driver.findElement(By.id("hobbies-checkbox-3")).click();
        driver.findElement(By.id("uploadPicture")).sendKeys("C:/Users/navee/OneDrive/Pictures/black_panther_is_sitting_in_car_background_4k_hd_black_panther-3840x2160.jpg");
        driver.findElement(By.id("currentAddress")).sendKeys("645/10 nehru nagar puliampatti,stathy,erode");
        WebElement city=driver.findElement(By.id("react-select-3-input"));
        city.sendKeys("NCR");
        city.sendKeys(Keys.ENTER);
        WebElement state=driver.findElement(By.id("react-select-4-input"));
        state.sendKeys("Delhi");
        state.sendKeys(Keys.ENTER);
        driver.findElement(By.id("submit")).sendKeys(Keys.ENTER);


    }
}