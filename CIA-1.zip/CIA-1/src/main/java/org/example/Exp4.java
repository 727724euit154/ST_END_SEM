package org.example;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Exp4 {

    @Test(priority=0)
    public void testAddition(){
        int result=10+90;
        Assert.assertEquals(100,result);
        System.out.println("TestCase Passed for sum = "+result);
    }

    @Test(priority = 1)
    public void testMulti(){
        int result=10*90;
        Assert.assertEquals(result,900);
        System.out.println("TestCase Passed");
    }
}
